#!/bin/sh
apt-get install libqt4-sql-psql
cp ./pgXplorer /usr/bin/
cp ./pgXplorer_ja.qm /usr/bin/
cp ./database.png /usr/share/pixmaps/
cp ./pgXplorer.desktop /usr/share/applications/
