#!/bin/sh
echo "Warning: This install script has to be run under"
echo "root priviliges to install necessary drivers and "
echo "copy files to appropriate paths."
echo""
apt-get install libqt4-sql-psql
cp ./pgXplorer /usr/bin/
cp ./pgXplorer_ja.qm /usr/bin/
cp ./qt_ja.qm /usr/bin/
cp ./database.png /usr/share/pixmaps/
cp ./pgXplorer.desktop /usr/share/applications/
